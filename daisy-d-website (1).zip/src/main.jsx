
import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import DaisyDWebsite from './DaisyDWebsite'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <DaisyDWebsite />
  </React.StrictMode>
)

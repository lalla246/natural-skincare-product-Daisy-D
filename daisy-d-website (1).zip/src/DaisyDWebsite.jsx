
import React from "react";
import { Mail, Leaf } from "lucide-react";
import { motion } from "framer-motion";

export default function DaisyDWebsite() {
  return (
    <div className="min-h-screen bg-pink-50 text-gray-800">
      <header className="p-6 bg-pink-200 shadow-md flex justify-between items-center">
        <h1 className="text-3xl font-bold text-pink-800">Daisy D</h1>
        <nav className="space-x-4">
          <a href="#about" className="hover:underline">À propos</a>
          <a href="#products" className="hover:underline">Produits</a>
          <a href="#contact" className="hover:underline">Contact</a>
        </nav>
      </header>
      <section className="text-center py-20 px-4">
        <motion.h2 
          className="text-4xl font-bold mb-4"
          initial={{ opacity: 0, y: -20 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 0.6 }}
        >
          Soin naturel pour une peau radieuse ✨
        </motion.h2>
        <p className="text-lg max-w-xl mx-auto">
          Bienvenue chez Daisy D — vos produits de soins faits maison, 100% naturels, doux pour votre peau et votre portefeuille.
        </p>
      </section>
      <section id="products" className="py-16 px-6 bg-white">
        <h3 className="text-3xl font-semibold text-center mb-10">Nos Produits</h3>
        <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          <div className="rounded-2xl shadow hover:shadow-lg p-6 bg-white">
            <h4 className="text-xl font-bold mb-2">Crème hydratante</h4>
            <p>Hydrate en profondeur avec des ingrédients 100% naturels. Parfait pour les peaux sensibles.</p>
          </div>
          <div className="rounded-2xl shadow hover:shadow-lg p-6 bg-white">
            <h4 className="text-xl font-bold mb-2">Exfoliant doux</h4>
            <p>Élimine les cellules mortes sans agresser votre peau. Convient à un usage hebdomadaire.</p>
          </div>
          <div className="rounded-2xl shadow hover:shadow-lg p-6 bg-white">
            <h4 className="text-xl font-bold mb-2">Baume à lèvres</h4>
            <p>Protège et adoucit les lèvres sèches. Arômes naturels et hydratation longue durée.</p>
          </div>
        </div>
      </section>
      <section id="about" className="py-20 px-6 bg-pink-100">
        <div className="max-w-4xl mx-auto text-center">
          <Leaf className="mx-auto text-pink-700 mb-4" size={40} />
          <h3 className="text-3xl font-bold mb-4">Notre Histoire</h3>
          <p>
            Née d'une passion pour la beauté naturelle, Daisy D a été fondée avec l'objectif d'offrir des soins doux, efficaces et abordables à toutes les femmes. Chaque produit est fabriqué à la main avec amour et des ingrédients locaux de qualité.
          </p>
        </div>
      </section>
      <section id="contact" className="py-16 px-6">
        <div className="max-w-xl mx-auto text-center">
          <Mail className="mx-auto text-pink-700 mb-4" size={36} />
          <h3 className="text-2xl font-semibold mb-2">Contactez-nous</h3>
          <p className="mb-4">Pour toute commande ou information, écrivez-nous :</p>
          <button className="bg-pink-600 hover:bg-pink-700 text-white px-4 py-2 rounded-full">
            daisy.d.skincare@gmail.com
          </button>
        </div>
      </section>
      <footer className="bg-pink-200 text-center py-4 text-sm">
        © 2025 Daisy D - Tous droits réservés
      </footer>
    </div>
  );
}
